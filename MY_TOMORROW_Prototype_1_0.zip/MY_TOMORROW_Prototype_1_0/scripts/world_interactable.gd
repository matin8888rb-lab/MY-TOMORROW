extends Area3D

signal activated(interaction_id: String)

@export var interaction_id: String = ""
@export var display_name: String = "Interact"
@export var hint_text: String = "Press USE"

func _ready() -> void:
    collision_layer = 0
    collision_mask = 1
    monitoring = true
    body_entered.connect(_on_body_entered)
    body_exited.connect(_on_body_exited)

func activate() -> void:
    activated.emit(interaction_id)

func _on_body_entered(body: Node3D) -> void:
    if body.has_method("set_nearby_interactable"):
        body.call("set_nearby_interactable", self)

func _on_body_exited(body: Node3D) -> void:
    if body.has_method("set_nearby_interactable"):
        if body.get("nearby_interactable") == self:
            body.call("set_nearby_interactable", null)
