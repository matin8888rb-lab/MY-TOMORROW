extends Node

const SAVE_PATH := "user://valora_save.json"

var player: CharacterBody3D
var money: int = 60
var character_name: String = "Alex"
var day_number: int = 1
var day_clock_minutes: float = 480.0
var outfit_index: int = 0
var skin_index: int = 0
var shift_completed_today: bool = false
var active_job: String = "warehouse"
var apartment_owned: bool = false
var furniture_owned: bool = false
var food_stock: int = 0
var hunger: float = 82.0
var energy: float = 90.0
var needs_tick: float = 0.0
var room_rented: bool = false
var groceries_bought: bool = false
var job_accepted: bool = false
var first_shift_done: bool = false
var objective: String = "Find a room to rent in Valora."
var notification: String = "Welcome to Valora. You have VC 60."
var notification_time: float = 5.0
var tom_met: bool = false
var tom_dialogue_step: int = 0
var story_quest_stage: int = 0
var daily_task_day: int = 0
var daily_task_completed: bool = false
var daily_task_id: String = "talk_maya"
var dialogue_title: String = ""
var dialogue_text: String = ""
var save_message: String = ""
var autosave_timer: float = 0.0

func _ready() -> void:
    player = get_parent().get_node("Player")
    load_game()
    _refresh_daily_task()
    player.set_appearance(outfit_index, skin_index)
    _notify("Welcome back to Valora.")

func register_interactable(area: Area3D) -> void:
    if not area.activated.is_connected(_on_interactable_activated):
        area.activated.connect(_on_interactable_activated)

func _process(delta: float) -> void:
    notification_time = maxf(0.0, notification_time - delta)
    if notification_time <= 0.0:
        notification = ""
    needs_tick += delta
    if needs_tick >= 15.0:
        needs_tick = 0.0
        hunger = maxf(0.0, hunger - 2.0)
        energy = maxf(0.0, energy - 1.0)
        if hunger <= 20.0:
            _notify("You are getting hungry. Eat something at home.")
        elif energy <= 20.0:
            _notify("You are tired. Rest at your room.")
    autosave_timer += delta
    if autosave_timer >= 15.0:
        autosave_timer = 0.0
        save_game(false)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
        save_game()

func _on_interactable_activated(interaction_id: String) -> void:
    match interaction_id:
        "rent_room":
            if room_rented:
                _notify("You already have a room in Valora.")
            elif money >= 25:
                money -= 25
                room_rented = true
                objective = "Buy groceries from the corner shop."
                _notify("Room rented! You paid VC 25. A new start begins.")
                save_game()
            else:
                _notify("You need VC 25 to rent this room.")
        "grocery_shop":
            if not room_rented:
                _notify("Find a room first. You need somewhere to keep your things.")
            elif groceries_bought:
                _notify("You already bought your first groceries.")
            elif money >= 8:
                money -= 8
                groceries_bought = true
                food_stock += 2
                objective = "Find a job. Check the noticeboard near the square."
                _notify("Groceries purchased for VC 8. You received 2 meal packs.")
                save_game()
            else:
                _notify("Not enough money for groceries.")
        "job_board":
            _accept_job("warehouse")
        "warehouse":
            _complete_shift("warehouse", 35)
        "delivery_work":
            _complete_shift("delivery", 42)
        "cafe_work":
            _complete_shift("cafe", 38)
        "delivery_job":
            _accept_job("delivery")
        "cafe_job":
            _accept_job("cafe")
        "furniture_shop":
            if not room_rented:
                _notify("Rent a room before buying furniture.")
            elif furniture_owned:
                _notify("Your room already has its starter furniture set.")
            elif money >= 18:
                money -= 18
                furniture_owned = true
                _notify("Furniture set purchased for VC 18. Your room feels more like home.")
                save_game()
            else:
                _notify("You need VC 18 for the furniture set.")
        "property_office":
            if not room_rented:
                _notify("You need to rent your first room before buying property.")
            elif apartment_owned:
                _notify("You already own the small apartment in Valora.")
            elif money >= 120:
                money -= 120
                apartment_owned = true
                _notify("Congratulations! You bought your first Valora apartment for VC 120.")
                save_game()
            else:
                _notify("The apartment costs VC 120. Keep saving.")
        "eat_food":
            if food_stock > 0:
                food_stock -= 1
                hunger = minf(100.0, hunger + 38.0)
                _notify("You ate a meal. Hunger is now " + str(int(hunger)) + " percent.")
                save_game(false)
            else:
                _notify("No food left. Buy groceries at the corner shop.")
        "npc_maya":
            _notify("MAYA: Welcome to the Copper Kettle. I work the morning shift. Tom usually visits the square after lunch.")
            _complete_daily_task("talk_maya")
        "town_hall":
            _advance_story_quest("town_hall")
        "library":
            _advance_story_quest("library")
        "park_bench":
            energy = minf(100.0, energy + 12.0)
            _notify("You took a quiet break in the park. Energy +12%.")
            _complete_daily_task("park_break")
            save_game(false)
        "buy_food":
            if not room_rented:
                _notify("Rent a room before stocking groceries.")
            elif money >= 8:
                money -= 8
                food_stock += 1
                _notify("Groceries added to your supplies. Food packs: " + str(food_stock))
                save_game()
            else:
                _notify("Not enough money. Groceries cost VC 8.")
        "enter_home":
            if not room_rented:
                _notify("Rent a room first. This is your home entrance.")
            else:
                player.global_position = Vector3(0.0, 0.9, 72.0)
                _notify("You are home. Rest, then head back into Valora.")
        "exit_home":
            player.global_position = Vector3(-9.0, 0.9, 4.0)
            _notify("You stepped outside into Valora.")
        "sleep":
            if not room_rented:
                _notify("You need to rent a room before you can rest here.")
            else:
                day_number += 1
                _refresh_daily_task(true)
                day_clock_minutes = 7.5 * 60.0
                energy = 100.0
                hunger = maxf(0.0, hunger - 8.0)
                shift_completed_today = false
                objective = "A new day in Valora. Choose a job or explore the town."
                _notify("Good morning! Day " + str(day_number) + " has begun.")
                save_game()
        "npc_tom":
            _talk_to_tom()
        _:
            _notify("Nothing to do here yet.")

func _accept_job(job_id: String) -> void:
    if not groceries_bought:
        _notify("Settle into your room and buy your first groceries first.")
        return
    if shift_completed_today:
        _notify("You have already worked today. Rest before taking another shift.")
        return
    active_job = job_id
    job_accepted = true
    var job_name := "delivery route" if job_id == "delivery" else "cafe assistant"
    objective = "Complete your " + job_name + " shift."
    _notify("Job selected: " + job_name + ". Visit the matching workplace.")
    save_game()

func _complete_shift(job_id: String, base_pay: int) -> void:
    if not job_accepted or active_job != job_id:
        _notify("You are not scheduled for this job. Check the town board.")
    elif shift_completed_today:
        _notify("You have already worked today. Rest at your room to start a new day.")
    else:
        first_shift_done = true
        shift_completed_today = true
        money += base_pay
        objective = "Explore Valora, improve your home, or rest for tomorrow."
        _notify("Shift complete! You earned VC " + str(base_pay) + ".")
        _complete_daily_task("work_shift")
        save_game()

func _advance_story_quest(location_id: String) -> void:
    if story_quest_stage == 0 and location_id == "town_hall":
        story_quest_stage = 1
        objective = "Visit the public library and learn about Valora."
        _notify("Town Hall: Welcome to Valora! The librarian has a local history leaflet for you.")
    elif story_quest_stage == 1 and location_id == "library":
        story_quest_stage = 2
        objective = "Find Tom in the town square and tell him what you learned."
        _notify("Library: You learned that Valora grew around its old railway station. Find Tom to continue.")
    elif story_quest_stage >= 2 and location_id == "town_hall":
        _notify("The Town Hall is quiet today. Your next story lead is at the town square.")
    elif story_quest_stage >= 3 and location_id == "library":
        _notify("The librarian smiles: 'Enjoy your new life in Valora!'")
    else:
        _notify("This place is part of Valora's story. Explore the town to discover more.")
    save_game(false)

func _talk_to_tom() -> void:
    tom_met = true
    if story_quest_stage == 2:
        story_quest_stage = 3
        money += 25
        dialogue_title = "TOM"
        dialogue_text = "So you found out about the railway. That station brought people here from all over. Here, take VC 25 to help you settle in. Welcome to Valora!"
        objective = "Your story begins. Explore Valora, work, and build your home."
        _notify("STORY COMPLETE: A Place to Call Home • Reward: VC 25")
        save_game(false)
        return
    match tom_dialogue_step:
        0:
            dialogue_title = "TOM"
            dialogue_text = "New in town? I'm Tom. If you're looking for work, the noticeboard by the square is the best place to start."
            tom_dialogue_step = 1
        1:
            dialogue_title = "TOM"
            dialogue_text = "The warehouse sometimes needs an extra pair of hands. It isn't glamorous, but it pays on time."
            tom_dialogue_step = 2
        _:
            dialogue_title = "TOM"
            dialogue_text = "Good to see you settling in. Valora can feel quiet at first, but give it time."
    _notify(dialogue_title + ": " + dialogue_text)
    save_game()

func _refresh_daily_task(force_new_day: bool = false) -> void:
    if force_new_day or daily_task_day != day_number:
        daily_task_day = day_number
        daily_task_completed = false
        match posmod(day_number - 1, 3):
            0:
                daily_task_id = "talk_maya"
            1:
                daily_task_id = "park_break"
            _:
                daily_task_id = "work_shift"

func _complete_daily_task(action_id: String) -> void:
    if daily_task_completed or action_id != daily_task_id:
        return
    daily_task_completed = true
    money += 12
    _notify("DAILY MISSION COMPLETE! Bonus: VC 12")
    save_game(false)

func _get_daily_task_text() -> String:
    var task_text := "Talk to Maya at the Copper Kettle"
    match daily_task_id:
        "park_break":
            task_text = "Take a break on the park bench"
        "work_shift":
            task_text = "Complete one work shift"
    return ("DAILY MISSION COMPLETE  •  " if daily_task_completed else "DAILY MISSION  •  ") + task_text + ("  •  VC 12" if not daily_task_completed else "")

func _notify(message: String) -> void:
    notification = message
    notification_time = 5.0

func save_game(show_notification: bool = true) -> void:
    if player == null or not is_instance_valid(player):
        return
    var data := {
        "version": 7,
        "money": money,
        "character_name": character_name,
        "day_number": day_number,
        "day_clock_minutes": day_clock_minutes,
        "outfit_index": outfit_index,
        "skin_index": skin_index,
        "shift_completed_today": shift_completed_today,
        "active_job": active_job,
        "apartment_owned": apartment_owned,
        "furniture_owned": furniture_owned,
        "food_stock": food_stock,
        "hunger": hunger,
        "energy": energy,
        "room_rented": room_rented,
        "groceries_bought": groceries_bought,
        "job_accepted": job_accepted,
        "first_shift_done": first_shift_done,
        "objective": objective,
        "story_quest": _get_story_quest_text(),
        "daily_mission": _get_daily_task_text(),
        "tom_met": tom_met,
        "tom_dialogue_step": tom_dialogue_step,
        "story_quest_stage": story_quest_stage,
        "daily_task_day": daily_task_day,
        "daily_task_completed": daily_task_completed,
        "daily_task_id": daily_task_id,
        "player_position": [
            player.global_position.x,
            player.global_position.y,
            player.global_position.z
        ]
    }
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        _notify("Save failed. Check device storage permissions.")
        return
    file.store_string(JSON.stringify(data))
    file.close()
    save_message = "Saved"
    if show_notification:
        _notify("Progress saved.")

func load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        _notify("Save file could not be opened.")
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        _notify("Save file is invalid. Starting a new game.")
        return
    var data: Dictionary = parsed
    var loaded_version := int(data.get("version", 1))
    money = maxi(0, int(data.get("money", 60)))
    character_name = str(data.get("character_name", "Alex"))
    day_number = maxi(1, int(data.get("day_number", 1)))
    day_clock_minutes = clampf(float(data.get("day_clock_minutes", 480.0)), 0.0, 1439.99)
    outfit_index = posmod(int(data.get("outfit_index", 0)), 5)
    skin_index = posmod(int(data.get("skin_index", 0)), 4)
    shift_completed_today = bool(data.get("shift_completed_today", false))
    active_job = str(data.get("active_job", "warehouse"))
    if not (active_job in ["warehouse", "delivery", "cafe"]):
        active_job = "warehouse"
    apartment_owned = bool(data.get("apartment_owned", false))
    furniture_owned = bool(data.get("furniture_owned", false))
    food_stock = clampi(int(data.get("food_stock", 0)), 0, 999)
    if loaded_version < 7 and bool(data.get("groceries_bought", false)) and food_stock == 0:
        food_stock = 2
    hunger = clampf(float(data.get("hunger", 82.0)), 0.0, 100.0)
    energy = clampf(float(data.get("energy", 90.0)), 0.0, 100.0)
    room_rented = bool(data.get("room_rented", false))
    groceries_bought = bool(data.get("groceries_bought", false))
    job_accepted = bool(data.get("job_accepted", false))
    first_shift_done = bool(data.get("first_shift_done", false))
    objective = str(data.get("objective", "Find a room to rent in Valora."))
    tom_met = bool(data.get("tom_met", false))
    tom_dialogue_step = clampi(int(data.get("tom_dialogue_step", 0)), 0, 2)
    story_quest_stage = clampi(int(data.get("story_quest_stage", 0)), 0, 3)
    daily_task_day = int(data.get("daily_task_day", 0))
    daily_task_completed = bool(data.get("daily_task_completed", false))
    daily_task_id = str(data.get("daily_task_id", "talk_maya"))
    if not (daily_task_id in ["talk_maya", "park_break", "work_shift"]):
        daily_task_id = "talk_maya"
    var saved_position: Variant = data.get("player_position", [0.0, 0.9, 8.0])
    if saved_position is Array and saved_position.size() == 3:
        player.global_position = Vector3(
            float(saved_position[0]),
            float(saved_position[1]),
            float(saved_position[2])
        )

func get_hud_state() -> Dictionary:
    var prompt := ""
    if player != null and is_instance_valid(player.nearby_interactable):
        prompt = "USE  •  " + str(player.nearby_interactable.display_name)
    return {
        "money": money,
        "character_name": character_name,
        "day_number": day_number,
        "clock": _format_clock(day_clock_minutes),
        "objective": objective,
        "story_quest": _get_story_quest_text(),
        "daily_mission": _get_daily_task_text(),
        "notification": notification,
        "prompt": prompt,
        "completed": first_shift_done,
        "food_stock": food_stock,
        "hunger": hunger,
        "energy": energy,
        "home_status": "OWNED APARTMENT" if apartment_owned else ("FURNISHED ROOM" if furniture_owned else ("RENTED ROOM" if room_rented else "NO HOME")),
        "active_job": active_job
    }

func _get_story_quest_text() -> String:
    match story_quest_stage:
        0:
            return "STORY: A PLACE TO CALL HOME  •  Visit Town Hall"
        1:
            return "STORY: A PLACE TO CALL HOME  •  Visit the Library"
        2:
            return "STORY: A PLACE TO CALL HOME  •  Find Tom at the Square"
        _:
            return "STORY COMPLETE  •  A PLACE TO CALL HOME"

func update_character(new_name: String, new_outfit: int, new_skin: int) -> void:
    var cleaned_name := new_name.strip_edges()
    if cleaned_name.is_empty():
        cleaned_name = "Alex"
    character_name = cleaned_name.substr(0, 18)
    outfit_index = posmod(new_outfit, 5)
    skin_index = posmod(new_skin, 4)
    player.set_appearance(outfit_index, skin_index)
    _notify("Character updated: " + character_name)
    save_game()

func _format_clock(minutes_value: float) -> String:
    var total_minutes := int(fposmod(minutes_value, 1440.0))
    var hour := int(total_minutes / 60)
    var minute := total_minutes % 60
    return "%02d:%02d" % [hour, minute]
