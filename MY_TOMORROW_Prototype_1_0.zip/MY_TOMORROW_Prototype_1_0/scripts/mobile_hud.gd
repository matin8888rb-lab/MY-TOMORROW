extends CanvasLayer

var manager: Node
var money_label: Label
var objective_label: Label
var prompt_label: Label
var notification_label: Label
var completion_label: Label
var day_label: Label
var clock_label: Label
var character_label: Label
var home_label: Label
var supplies_label: Label
var needs_label: Label
var story_label: Label
var mission_label: Label
var customization_panel: PanelContainer
var name_input: LineEdit
var outfit_index: int = 0
var skin_index: int = 0

func _ready() -> void:
    manager = get_parent().get_node("GameManager")
    _build_interface()
    _build_controls()

func _process(_delta: float) -> void:
    if manager == null:
        return
    var state: Dictionary = manager.call("get_hud_state")
    money_label.text = "VC  " + str(state["money"])
    objective_label.text = "CURRENT GOAL\n" + str(state["objective"])
    prompt_label.text = str(state["prompt"])
    notification_label.text = str(state["notification"])
    completion_label.visible = bool(state["completed"])
    day_label.text = "DAY " + str(state["day_number"])
    clock_label.text = str(state["clock"])
    character_label.text = str(state["character_name"])
    home_label.text = str(state["home_status"])
    supplies_label.text = "FOOD " + str(state["food_stock"]) + "  •  JOB " + str(state["active_job"]).to_upper()
    needs_label.text = "HUNGER " + str(state["hunger"]) + "%   ENERGY " + str(state["energy"]) + "%"
    story_label.text = str(state["story_quest"])
    mission_label.text = str(state["daily_mission"])

func _build_interface() -> void:
    var root := Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)

    var title := Label.new()
    title.text = "VALORA  •  2000  •  1.0"
    title.position = Vector2(22, 14)
    title.add_theme_font_size_override("font_size", 23)
    title.add_theme_color_override("font_color", Color("#f4e9d5"))
    root.add_child(title)

    money_label = _panel_label(root, Vector2(-190, 18), Vector2(168, 44), 21, true)
    money_label.anchor_left = 1.0
    money_label.anchor_right = 1.0
    objective_label = _panel_label(root, Vector2(22, 58), Vector2(390, 86), 17, false)
    notification_label = _panel_label(root, Vector2(0, 160), Vector2(560, 48), 16, true)
    notification_label.anchor_left = 0.5
    notification_label.anchor_right = 0.5
    notification_label.position.x = -280
    prompt_label = _panel_label(root, Vector2(0, -220), Vector2(340, 44), 18, true)
    prompt_label.anchor_left = 0.5
    prompt_label.anchor_right = 0.5
    prompt_label.anchor_top = 1.0
    prompt_label.anchor_bottom = 1.0
    prompt_label.position.x = -170
    completion_label = _panel_label(root, Vector2(0, 215), Vector2(390, 48), 19, true)
    completion_label.anchor_left = 0.5
    completion_label.anchor_right = 0.5
    completion_label.position.x = -195
    completion_label.text = "FIRST DAY COMPLETE  •  FREE ROAM"
    completion_label.visible = false

    day_label = _panel_label(root, Vector2(22, 44), Vector2(150, 30), 15, false)
    clock_label = _panel_label(root, Vector2(180, 44), Vector2(100, 30), 15, false)
    character_label = _panel_label(root, Vector2(22, 76), Vector2(190, 28), 15, false)
    home_label = _panel_label(root, Vector2(22, 102), Vector2(220, 26), 13, false)
    supplies_label = _panel_label(root, Vector2(22, 128), Vector2(300, 26), 12, false)
    needs_label = _panel_label(root, Vector2(22, 151), Vector2(330, 25), 12, false)
    story_label = _panel_label(root, Vector2(22, 207), Vector2(500, 26), 13, false)
    mission_label = _panel_label(root, Vector2(22, 232), Vector2(520, 26), 13, false)

    var customize_button := Button.new()
    customize_button.text = "CHARACTER"
    customize_button.position = Vector2(22, 264)
    customize_button.size = Vector2(142, 42)
    customize_button.add_theme_font_size_override("font_size", 14)
    root.add_child(customize_button)
    customize_button.pressed.connect(_toggle_customization)
    _build_customization(root)

func _build_customization(root: Control) -> void:
    customization_panel = PanelContainer.new()
    customization_panel.position = Vector2(0, 0)
    customization_panel.size = Vector2(330, 245)
    customization_panel.anchor_left = 0.5
    customization_panel.anchor_right = 0.5
    customization_panel.anchor_top = 0.5
    customization_panel.anchor_bottom = 0.5
    customization_panel.offset_left = -165
    customization_panel.offset_right = 165
    customization_panel.offset_top = -122
    customization_panel.offset_bottom = 123
    customization_panel.visible = false
    root.add_child(customization_panel)

    var layout := VBoxContainer.new()
    layout.add_theme_constant_override("separation", 9)
    customization_panel.add_child(layout)

    var heading := Label.new()
    heading.text = "YOUR CHARACTER"
    heading.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    heading.add_theme_font_size_override("font_size", 19)
    layout.add_child(heading)

    name_input = LineEdit.new()
    name_input.placeholder_text = "Character name"
    name_input.max_length = 18
    name_input.text = "Alex"
    layout.add_child(name_input)

    var outfit_row := HBoxContainer.new()
    layout.add_child(outfit_row)
    var outfit_button := Button.new()
    outfit_button.text = "CHANGE OUTFIT"
    outfit_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    outfit_row.add_child(outfit_button)
    outfit_button.pressed.connect(func():
        outfit_index = (outfit_index + 1) % 5
        _save_character()
    )

    var skin_row := HBoxContainer.new()
    layout.add_child(skin_row)
    var skin_button := Button.new()
    skin_button.text = "CHANGE SKIN TONE"
    skin_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    skin_row.add_child(skin_button)
    skin_button.pressed.connect(func():
        skin_index = (skin_index + 1) % 4
        _save_character()
    )

    var actions := HBoxContainer.new()
    layout.add_child(actions)
    var save_button := Button.new()
    save_button.text = "SAVE"
    save_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    actions.add_child(save_button)
    save_button.pressed.connect(_save_character)
    var close_button := Button.new()
    close_button.text = "CLOSE"
    close_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    actions.add_child(close_button)
    close_button.pressed.connect(_toggle_customization)

func _toggle_customization() -> void:
    customization_panel.visible = not customization_panel.visible
    if customization_panel.visible:
        name_input.text = str(manager.get("character_name"))
        outfit_index = int(manager.get("outfit_index"))
        skin_index = int(manager.get("skin_index"))

func _save_character() -> void:
    manager.call("update_character", name_input.text, outfit_index, skin_index)

func _panel_label(parent: Control, pos: Vector2, dimensions: Vector2, font_size: int, centered: bool) -> Label:
    var label := Label.new()
    label.position = pos
    label.size = dimensions
    label.add_theme_font_size_override("font_size", font_size)
    label.add_theme_color_override("font_color", Color("#fff4df"))
    label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
    label.add_theme_constant_override("shadow_offset_x", 2)
    label.add_theme_constant_override("shadow_offset_y", 2)
    if centered:
        label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
        label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    parent.add_child(label)
    return label

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_WM_CLOSE_REQUEST:
        for action in ["move_forward", "move_back", "move_left", "move_right", "run", "interact"]:
            if Input.is_action_pressed(action):
                Input.action_release(action)

func _build_controls() -> void:
    var root := get_child(0) as Control
    _make_action_button(root, "↑", "move_forward", Vector2(92, -168))
    _make_action_button(root, "↓", "move_back", Vector2(92, -66))
    _make_action_button(root, "←", "move_left", Vector2(38, -112))
    _make_action_button(root, "→", "move_right", Vector2(146, -112))
    _make_action_button(root, "RUN", "run", Vector2(-190, -120), Vector2(82, 62))
    _make_action_button(root, "USE", "interact", Vector2(-98, -70), Vector2(82, 62))

func _make_action_button(parent: Control, caption: String, action: String, offset: Vector2, size: Vector2 = Vector2(58, 58)) -> void:
    var button := Button.new()
    button.text = caption
    button.size = size
    button.anchor_left = 0.0 if offset.x >= 0 else 1.0
    button.anchor_right = button.anchor_left
    button.anchor_top = 1.0
    button.anchor_bottom = 1.0
    button.position = offset
    button.modulate = Color(0.9, 0.94, 1.0, 0.84)
    button.add_theme_font_size_override("font_size", 18)
    parent.add_child(button)
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))
    button.mouse_exited.connect(func():
        if Input.is_action_pressed(action):
            Input.action_release(action)
    )
