extends CharacterBody3D

@export_group("Movement")
@export var walk_speed: float = 3.8
@export var run_speed: float = 5.8
@export var acceleration: float = 15.0
@export var braking: float = 20.0
@export var gravity: float = 18.0

@export_group("Camera")
@export var mouse_sensitivity: float = 0.0035
@export var touch_sensitivity: float = 0.0045
@export var min_camera_pitch: float = -0.65
@export var max_camera_pitch: float = 0.18

@onready var spring_arm: SpringArm3D = $SpringArm3D

var camera_yaw: float = 0.0
var camera_pitch: float = -0.12
var walk_phase: float = 0.0
var visual_root: Node3D
var left_arm: Node3D
var right_arm: Node3D
var left_leg: Node3D
var right_leg: Node3D
var torso: Node3D
var nearby_interactable: Area3D
var jacket_material: StandardMaterial3D
var skin_material: StandardMaterial3D
var outfit_index: int = 0
var skin_index: int = 0
const OUTFIT_COLORS := [Color("#344b62"), Color("#6c5948"), Color("#426b58"), Color("#6b4c70"), Color("#34383e")]
const SKIN_COLORS := [Color("#c99776"), Color("#8d6048"), Color("#e0b99a"), Color("#a87555")]

func _ready() -> void:
    Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
    _build_character_visual()
    _apply_camera_rotation()

func set_nearby_interactable(target: Area3D) -> void:
    nearby_interactable = target

func _unhandled_input(event: InputEvent) -> void:
    if event is InputEventMouseMotion and Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT):
        _rotate_camera(event.relative, mouse_sensitivity)
    elif event is InputEventScreenDrag:
        var viewport_width := get_viewport().get_visible_rect().size.x
        if event.position.x > viewport_width * 0.48:
            _rotate_camera(event.relative, touch_sensitivity)

func _rotate_camera(relative: Vector2, sensitivity: float) -> void:
    camera_yaw -= relative.x * sensitivity
    camera_pitch = clamp(camera_pitch - relative.y * sensitivity, min_camera_pitch, max_camera_pitch)
    _apply_camera_rotation()

func _physics_process(delta: float) -> void:
    var input_vector := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
    var camera_basis := spring_arm.global_transform.basis
    var forward := -camera_basis.z
    var right := camera_basis.x
    forward.y = 0.0
    right.y = 0.0
    forward = forward.normalized()
    right = right.normalized()

    var direction := (right * input_vector.x - forward * input_vector.y).normalized()
    var moving := direction.length_squared() > 0.001
    var running := moving and Input.is_action_pressed("run")
    var target_speed := run_speed if running else walk_speed
    var rate := acceleration if moving else braking

    if moving:
        velocity.x = move_toward(velocity.x, direction.x * target_speed, rate * delta)
        velocity.z = move_toward(velocity.z, direction.z * target_speed, rate * delta)
        var target_rotation := atan2(direction.x, direction.z)
        rotation.y = lerp_angle(rotation.y, target_rotation, min(10.0 * delta, 1.0))
    else:
        velocity.x = move_toward(velocity.x, 0.0, braking * delta)
        velocity.z = move_toward(velocity.z, 0.0, braking * delta)

    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = -0.1

    move_and_slide()
    _animate_character(delta, moving, running)

    if Input.is_action_just_pressed("interact") and nearby_interactable != null:
        nearby_interactable.call("activate")

func _build_character_visual() -> void:
    visual_root = Node3D.new()
    visual_root.name = "CharacterVisual"
    add_child(visual_root)

    jacket_material = _make_material(OUTFIT_COLORS[outfit_index])
    var trousers := _make_material(Color(0.16, 0.19, 0.22))
    skin_material = _make_material(SKIN_COLORS[skin_index])
    var shoes := _make_material(Color(0.10, 0.11, 0.12))

    torso = _make_part("Torso", Vector3(0.0, 1.05, 0.0), Vector3(0.48, 0.72, 0.27), jacket_material)
    visual_root.add_child(torso)
    _make_sphere("Head", Vector3(0.0, 1.72, 0.0), 0.19, skin_material, visual_root)

    left_arm = _make_limb("LeftArm", Vector3(-0.32, 1.34, 0.0), 0.64, 0.105, jacket_material)
    right_arm = _make_limb("RightArm", Vector3(0.32, 1.34, 0.0), 0.64, 0.105, jacket_material)
    visual_root.add_child(left_arm)
    visual_root.add_child(right_arm)

    left_leg = _make_limb("LeftLeg", Vector3(-0.14, 0.72, 0.0), 0.72, 0.13, trousers)
    right_leg = _make_limb("RightLeg", Vector3(0.14, 0.72, 0.0), 0.72, 0.13, trousers)
    visual_root.add_child(left_leg)
    visual_root.add_child(right_leg)

    _make_box_part("LeftShoe", Vector3(-0.14, 0.12, -0.055), Vector3(0.22, 0.13, 0.34), shoes, visual_root)
    _make_box_part("RightShoe", Vector3(0.14, 0.12, -0.055), Vector3(0.22, 0.13, 0.34), shoes, visual_root)

func _make_material(color: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = 0.88
    return material

func _make_part(part_name: String, part_position: Vector3, part_size: Vector3, material: Material) -> MeshInstance3D:
    var part := MeshInstance3D.new()
    part.name = part_name
    var mesh := CapsuleMesh.new()
    mesh.radius = min(part_size.x, part_size.z) * 0.5
    mesh.height = part_size.y
    part.mesh = mesh
    part.position = part_position
    part.material_override = material
    return part

func _make_box_part(part_name: String, part_position: Vector3, part_size: Vector3, material: Material, parent: Node) -> void:
    var part := MeshInstance3D.new()
    part.name = part_name
    var mesh := BoxMesh.new()
    mesh.size = part_size
    part.mesh = mesh
    part.position = part_position
    part.material_override = material
    parent.add_child(part)

func _make_sphere(part_name: String, part_position: Vector3, radius: float, material: Material, parent: Node) -> void:
    var part := MeshInstance3D.new()
    part.name = part_name
    var mesh := SphereMesh.new()
    mesh.radius = radius
    mesh.height = radius * 2.0
    part.mesh = mesh
    part.position = part_position
    part.material_override = material
    parent.add_child(part)

func _make_limb(part_name: String, pivot_position: Vector3, length: float, radius: float, material: Material) -> Node3D:
    var pivot := Node3D.new()
    pivot.name = part_name
    pivot.position = pivot_position
    var mesh_instance := MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = radius
    mesh.height = length
    mesh_instance.mesh = mesh
    mesh_instance.position.y = -length * 0.43
    mesh_instance.material_override = material
    pivot.add_child(mesh_instance)
    return pivot

func _animate_character(delta: float, moving: bool, running: bool) -> void:
    if visual_root == null:
        return
    if moving:
        var frequency := 10.5 if running else 7.5
        walk_phase += delta * frequency
        var swing := sin(walk_phase) * (0.72 if running else 0.48)
        left_leg.rotation.x = swing
        right_leg.rotation.x = -swing
        left_arm.rotation.x = -swing * 0.72
        right_arm.rotation.x = swing * 0.72
        visual_root.position.y = abs(sin(walk_phase * 2.0)) * (0.045 if running else 0.025)
        torso.rotation.z = lerp(torso.rotation.z, -swing * 0.035, min(8.0 * delta, 1.0))
    else:
        left_leg.rotation.x = lerp_angle(left_leg.rotation.x, 0.0, min(9.0 * delta, 1.0))
        right_leg.rotation.x = lerp_angle(right_leg.rotation.x, 0.0, min(9.0 * delta, 1.0))
        left_arm.rotation.x = lerp_angle(left_arm.rotation.x, 0.0, min(9.0 * delta, 1.0))
        right_arm.rotation.x = lerp_angle(right_arm.rotation.x, 0.0, min(9.0 * delta, 1.0))
        visual_root.position.y = lerp(visual_root.position.y, 0.0, min(8.0 * delta, 1.0))
        torso.rotation.z = lerp(torso.rotation.z, 0.0, min(8.0 * delta, 1.0))

func _apply_camera_rotation() -> void:
    spring_arm.rotation.y = camera_yaw
    spring_arm.rotation.x = camera_pitch
