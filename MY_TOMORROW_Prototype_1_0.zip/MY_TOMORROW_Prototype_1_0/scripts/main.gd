extends Node3D

const INTERACTABLE_SCRIPT = preload("res://scripts/world_interactable.gd")

@onready var manager: Node = $GameManager

var day_clock_minutes: float = 8.0 * 60.0
var day_clock_speed: float = 2.0 # in-game minutes per real second

func _ready() -> void:
    day_clock_minutes = float(manager.get("day_clock_minutes"))
    _style_existing_blockout()
    _build_city_details()
    _build_home_interior()
    _build_interaction_points()
    _build_story_interaction_points()
    _build_tom_npc()
    _build_maya_npc()
    _update_day_lighting()

func _process(delta: float) -> void:
    day_clock_minutes = fposmod(float(manager.get("day_clock_minutes")) + delta * day_clock_speed, 24.0 * 60.0)
    manager.set("day_clock_minutes", day_clock_minutes)
    _update_day_lighting()
    _update_npc_schedule()

func _update_npc_schedule() -> void:
    var tom_area := get_node_or_null("TomInteraction") as Node3D
    var tom_actor := get_node_or_null("TomNPC") as Node3D
    if tom_area == null or tom_actor == null:
        return
    var hour := day_clock_minutes / 60.0
    var destination := Vector3(-4.5, 0.0, -18.0)
    if hour >= 9.0 and hour < 13.0:
        destination = Vector3(-4.5, 0.0, -18.0)
    elif hour >= 13.0 and hour < 18.0:
        destination = Vector3(0.0, 0.0, -22.0)
    else:
        destination = Vector3(-17.0, 0.0, 11.0)
    tom_actor.position = tom_actor.position.lerp(destination, 0.018)
    tom_area.position = tom_actor.position

func _update_day_lighting() -> void:
    var hour := day_clock_minutes / 60.0
    var daylight := 0.0
    if hour >= 6.0 and hour <= 18.0:
        daylight = sin((hour - 6.0) / 12.0 * PI)
    var sun := get_node_or_null("Sun") as DirectionalLight3D
    if sun != null:
        sun.rotation_degrees = Vector3(-90.0 + (hour - 12.0) * 7.5, -28.0, 0.0)
        sun.light_energy = lerpf(0.08, 1.15, daylight)
    var world := get_node_or_null("WorldEnvironment") as WorldEnvironment
    if world != null and world.environment != null:
        world.environment.ambient_light_energy = lerpf(0.22, 0.82, daylight)
        world.environment.background_color = Color("#101a2b").lerp(Color("#7894ad"), daylight)

func _style_existing_blockout() -> void:
    var ground_mesh := MeshInstance3D.new()
    var ground_shape := BoxMesh.new()
    ground_shape.size = Vector3(80, 0.5, 80)
    ground_mesh.mesh = ground_shape
    ground_mesh.position.y = -0.25
    ground_mesh.material_override = _mat(Color("#777b70"))
    $Ground.add_child(ground_mesh)

    _add_box("Station", Vector3(0, 2, -13), Vector3(12, 4, 5), Color("#9a8c79"), true)
    _add_box("OldBuildingLeft", Vector3(-22, 2.5, -4), Vector3(7, 5, 8), Color("#8b5145"), true)
    _add_box("OldBuildingRight", Vector3(22, 2.5, -4), Vector3(7, 5, 8), Color("#8b5145"), true)
    _add_box("Cafe", Vector3(-10, 1.7, 13), Vector3(6, 3.4, 5), Color("#d2b78f"), true)

func _build_city_details() -> void:
    _add_box("MainRoad", Vector3(0, 0.015, 0), Vector3(8, 0.03, 54), Color("#45494a"), false)
    _add_box("PavementLeft", Vector3(-5.1, 0.03, 0), Vector3(2.1, 0.06, 54), Color("#b5ad9c"), false)
    _add_box("PavementRight", Vector3(5.1, 0.03, 0), Vector3(2.1, 0.06, 54), Color("#b5ad9c"), false)
    for z in range(-24, 25, 6):
        _add_box("RoadMarking", Vector3(0, 0.04, float(z)), Vector3(0.13, 0.02, 2.6), Color("#d8d0b8"), false)

    _add_box("RentalOffice", Vector3(-13, 2.1, -2), Vector3(7, 4.2, 7), Color("#a96f56"), true)
    _add_box("ShopBuilding", Vector3(13, 1.9, -8), Vector3(7, 3.8, 7), Color("#d1b58b"), true)
    _add_box("Warehouse", Vector3(17, 2.4, 13), Vector3(10, 4.8, 11), Color("#777d80"), true)
    _add_box("CafeWorkplace", Vector3(-19, 1.8, 14), Vector3(7, 3.6, 6), Color("#a96d4e"), true)
    _add_box("DeliveryDepot", Vector3(25, 2.0, -12), Vector3(8, 4.0, 8), Color("#748b91"), true)
    _add_box("PropertyOffice", Vector3(-25, 2.0, -15), Vector3(7, 4.0, 7), Color("#8c9b83"), true)
    _add_box("FurnitureShop", Vector3(25, 1.8, 4), Vector3(7, 3.6, 7), Color("#b28b67"), true)
    _add_box("TownHall", Vector3(-29, 2.2, 8), Vector3(8, 4.4, 10), Color("#a5a49a"), true)
    _add_box("Library", Vector3(-29, 1.9, 23), Vector3(8, 3.8, 9), Color("#8c9eaa"), true)

    _add_sign("ROOMS TO LET", Vector3(-13, 3.5, 1.58), Color("#f3e8d5"))
    _add_sign("CORNER SHOP", Vector3(13, 3.0, -4.38), Color("#fff0c8"))
    _add_sign("VALORA WAREHOUSE", Vector3(17, 4.0, 7.38), Color("#f0e7d6"))
    _add_sign("THE COPPER KETTLE CAFE", Vector3(-19, 3.0, 10.9), Color("#fff0d8"))
    _add_sign("CITY COURIERS", Vector3(25, 3.2, -8.0), Color("#e6f0e9"))
    _add_sign("VALORA HOMES", Vector3(-25, 3.2, -11.4), Color("#f0eadb"))
    _add_sign("SECOND LIFE FURNITURE", Vector3(25, 2.9, 0.4), Color("#fff0d8"))
    _add_sign("TOWN SQUARE", Vector3(0, 0.2, -23), Color("#e4ddc9"))
    _add_sign("VALORA TOWN HALL", Vector3(-29, 3.3, 3.0), Color("#f0eadb"))
    _add_sign("PUBLIC LIBRARY", Vector3(-29, 2.9, 18.5), Color("#e4edf0"))

    for x in [-8.0, 8.0]:
        for z in [-18.0, -6.0, 6.0, 18.0]:
            _add_streetlamp(Vector3(x, 0, z))
    for x in [10.0, 13.0, 16.0]:
        _add_tree(Vector3(x, 0, 18.0))
    _add_tree(Vector3(-18, 0, 12))
    _add_tree(Vector3(-18, 0, 18))
    _add_box("ParkLawn", Vector3(16, 0.08, 22), Vector3(14, 0.12, 10), Color("#78906a"), false)
    _add_box("BenchSeat", Vector3(16, 0.55, 22), Vector3(2.2, 0.14, 0.55), Color("#76543c"), false)
    _add_box("BenchBack", Vector3(16, 0.95, 22.2), Vector3(2.2, 0.65, 0.14), Color("#76543c"), false)

func _build_interaction_points() -> void:
    _add_interactable("RentalOfficePoint", "rent_room", "Rent a room", Vector3(-8.1, 0.0, -2.0), Color("#d6a86a"))
    _add_interactable("GroceryPoint", "grocery_shop", "Buy groceries", Vector3(8.9, 0.0, -8.0), Color("#83b5a0"))
    _add_interactable("JobBoardPoint", "job_board", "Read job board", Vector3(0.0, 0.0, -22.0), Color("#d8c47d"))
    _add_interactable("WarehousePoint", "warehouse", "Start warehouse shift", Vector3(11.0, 0.0, 13.0), Color("#a5b5c7"))
    _add_interactable("HomeDoorPoint", "enter_home", "Enter your room", Vector3(-9.0, 0.0, 2.2), Color("#8fb6c9"))
    _add_interactable("HomeExitPoint", "exit_home", "Leave your room", Vector3(0.0, 0.0, 73.0), Color("#8fb6c9"))
    _add_interactable("HomeSleepPoint", "sleep", "Sleep until morning", Vector3(2.4, 0.0, 68.6), Color("#d4b58a"))
    _add_interactable("DeliveryJobPoint", "delivery_job", "Apply: City Courier", Vector3(0.0, 0.0, -18.0), Color("#8bb9c0"))
    _add_interactable("CafeJobPoint", "cafe_job", "Apply: Cafe Assistant", Vector3(4.0, 0.0, -18.0), Color("#d9a27d"))
    _add_interactable("DeliveryWorkPoint", "delivery_work", "Complete courier shift", Vector3(19.0, 0.0, -12.0), Color("#8bb9c0"))
    _add_interactable("CafeWorkPoint", "cafe_work", "Start cafe shift", Vector3(-13.0, 0.0, 14.0), Color("#d9a27d"))
    _add_interactable("PropertyOfficePoint", "property_office", "Buy a small apartment", Vector3(-20.5, 0.0, -15.0), Color("#9ab18e"))
    _add_interactable("FurnitureShopPoint", "furniture_shop", "Buy room furniture", Vector3(20.5, 0.0, 4.0), Color("#c7a17b"))
    _add_interactable("FoodRestockPoint", "buy_food", "Buy groceries: VC 8", Vector3(8.9, 0.0, -5.5), Color("#83b5a0"))
    _add_interactable("EatFoodPoint", "eat_food", "Eat a meal", Vector3(1.5, 0.0, 70.0), Color("#d8b77b"))


func _build_home_interior() -> void:
    # A separate, enclosed interior zone keeps the first-person-sized room
    # lightweight while making it genuinely enterable on mobile hardware.
    _add_box("HomeFloor", Vector3(0, -0.12, 70), Vector3(10, 0.24, 8), Color("#9b8065"), true)
    _add_box("HomeBackWall", Vector3(0, 1.7, 66), Vector3(10, 3.4, 0.25), Color("#d8d0bf"), true)
    _add_box("HomeLeftWall", Vector3(-5, 1.7, 70), Vector3(0.25, 3.4, 8), Color("#c8c0b0"), true)
    _add_box("HomeRightWall", Vector3(5, 1.7, 70), Vector3(0.25, 3.4, 8), Color("#c8c0b0"), true)
    _add_box("HomeFrontLeft", Vector3(-3.5, 1.7, 74), Vector3(3, 3.4, 0.25), Color("#d8d0bf"), true)
    _add_box("HomeFrontRight", Vector3(3.5, 1.7, 74), Vector3(3, 3.4, 0.25), Color("#d8d0bf"), true)
    _add_box("HomeBedBase", Vector3(-2.8, 0.35, 68.0), Vector3(2.2, 0.45, 1.2), Color("#765b4b"), false)
    _add_box("HomeMattress", Vector3(-2.8, 0.66, 68.0), Vector3(2.15, 0.22, 1.16), Color("#e6e0d4"), false)
    _add_box("HomePillow", Vector3(-2.8, 0.82, 67.58), Vector3(0.75, 0.12, 0.42), Color("#b9c7ce"), false)
    _add_box("HomeTable", Vector3(2.4, 0.72, 71.2), Vector3(1.5, 0.12, 0.9), Color("#76543c"), false)
    _add_box("HomeTableLeg1", Vector3(1.8, 0.35, 70.85), Vector3(0.1, 0.7, 0.1), Color("#684a35"), false)
    _add_box("HomeTableLeg2", Vector3(3.0, 0.35, 70.85), Vector3(0.1, 0.7, 0.1), Color("#684a35"), false)
    _add_box("HomeTableLeg3", Vector3(1.8, 0.35, 71.55), Vector3(0.1, 0.7, 0.1), Color("#684a35"), false)
    _add_box("HomeTableLeg4", Vector3(3.0, 0.35, 71.55), Vector3(0.1, 0.7, 0.1), Color("#684a35"), false)
    _add_box("HomeWindow", Vector3(0, 2.1, 66.14), Vector3(2.2, 1.2, 0.04), Color("#7fa6b8"), false)
    _add_sign("YOUR ROOM", Vector3(0, 3.0, 66.2), Color("#66594d"))

func _build_story_interaction_points() -> void:
    _add_interactable("TownHallStoryPoint", "town_hall", "Visit Town Hall", Vector3(-23.0, 0.0, 8.0), Color("#d8c7a0"))
    _add_interactable("LibraryStoryPoint", "library", "Visit the Library", Vector3(-23.0, 0.0, 23.0), Color("#9bb9c9"))
    _add_interactable("ParkBenchPoint", "park_bench", "Take a break", Vector3(13.0, 0.0, 22.0), Color("#93b58b"))

func _build_tom_npc() -> void:
    var tom := Node3D.new()
    tom.name = "TomNPC"
    tom.position = Vector3(-4.5, 0.0, -18.0)
    add_child(tom)

    var body := MeshInstance3D.new()
    var body_mesh := CapsuleMesh.new()
    body_mesh.radius = 0.34
    body_mesh.height = 1.55
    body.mesh = body_mesh
    body.position.y = 0.83
    body.material_override = _mat(Color("#6d8190"))
    tom.add_child(body)

    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.19
    head_mesh.height = 0.38
    head.mesh = head_mesh
    head.position.y = 1.72
    head.material_override = _mat(Color("#c99776"))
    tom.add_child(head)

    var npc_area := Area3D.new()
    npc_area.name = "TomInteraction"
    npc_area.position = tom.position
    npc_area.set_script(INTERACTABLE_SCRIPT)
    npc_area.set("interaction_id", "npc_tom")
    npc_area.set("display_name", "Talk to Tom")
    var collision := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 2.8
    collision.shape = sphere
    npc_area.add_child(collision)
    var label := Label3D.new()
    label.text = "TOM"
    label.position.y = 2.15
    label.font_size = 34
    label.pixel_size = 0.006
    label.modulate = Color("#fff0d7")
    npc_area.add_child(label)
    add_child(npc_area)
    manager.register_interactable(npc_area)


func _build_maya_npc() -> void:
    var maya := Node3D.new()
    maya.name = "MayaNPC"
    maya.position = Vector3(-16.0, 0.0, 12.0)
    add_child(maya)
    var body := MeshInstance3D.new()
    var body_mesh := CapsuleMesh.new()
    body_mesh.radius = 0.31
    body_mesh.height = 1.5
    body.mesh = body_mesh
    body.position.y = 0.8
    body.material_override = _mat(Color("#8b6b91"))
    maya.add_child(body)
    var head := MeshInstance3D.new()
    var head_mesh := SphereMesh.new()
    head_mesh.radius = 0.18
    head_mesh.height = 0.36
    head.mesh = head_mesh
    head.position.y = 1.68
    head.material_override = _mat(Color("#d6a889"))
    maya.add_child(head)
    var area := Area3D.new()
    area.name = "MayaInteraction"
    area.position = maya.position
    area.set_script(INTERACTABLE_SCRIPT)
    area.set("interaction_id", "npc_maya")
    area.set("display_name", "Talk to Maya")
    var collision := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 2.8
    collision.shape = sphere
    area.add_child(collision)
    var label := Label3D.new()
    label.text = "MAYA"
    label.position.y = 2.1
    label.font_size = 32
    label.pixel_size = 0.006
    label.modulate = Color("#fff0d7")
    area.add_child(label)
    add_child(area)
    manager.register_interactable(area)

func _add_interactable(node_name: String, interaction_id: String, title: String, point: Vector3, color: Color) -> void:
    var area := Area3D.new()
    area.name = node_name
    area.position = point
    area.set_script(INTERACTABLE_SCRIPT)
    area.set("interaction_id", interaction_id)
    area.set("display_name", title)
    var collision := CollisionShape3D.new()
    var sphere := SphereShape3D.new()
    sphere.radius = 2.6
    collision.shape = sphere
    area.add_child(collision)
    var beacon := MeshInstance3D.new()
    var cylinder := CylinderMesh.new()
    cylinder.top_radius = 0.16
    cylinder.bottom_radius = 0.28
    cylinder.height = 0.9
    beacon.mesh = cylinder
    beacon.position.y = 0.48
    beacon.material_override = _mat(color)
    area.add_child(beacon)
    var label := Label3D.new()
    label.text = title.to_upper()
    label.position.y = 1.35
    label.font_size = 30
    label.pixel_size = 0.006
    label.modulate = Color("#fff4d8")
    area.add_child(label)
    add_child(area)
    manager.call("register_interactable", area)

func _add_box(node_name: String, point: Vector3, dimensions: Vector3, color: Color, solid: bool) -> void:
    var parent: Node3D
    if solid:
        parent = StaticBody3D.new()
        parent.name = node_name
        parent.position = point
        var shape_node := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = dimensions
        shape_node.shape = shape
        parent.add_child(shape_node)
    else:
        parent = Node3D.new()
        parent.name = node_name
        parent.position = point
    var mesh_instance := MeshInstance3D.new()
    var mesh := BoxMesh.new()
    mesh.size = dimensions
    mesh_instance.mesh = mesh
    mesh_instance.material_override = _mat(color)
    parent.add_child(mesh_instance)
    add_child(parent)

func _add_sign(text_value: String, point: Vector3, color: Color) -> void:
    var label := Label3D.new()
    label.text = text_value
    label.position = point
    label.font_size = 42
    label.pixel_size = 0.008
    label.modulate = color
    add_child(label)

func _add_streetlamp(point: Vector3) -> void:
    _add_box("LampPost", point + Vector3(0, 2.0, 0), Vector3(0.12, 4.0, 0.12), Color("#343b40"), false)
    _add_box("LampHead", point + Vector3(0, 4.05, 0), Vector3(0.65, 0.18, 0.32), Color("#e2d3a7"), false)

func _add_tree(point: Vector3) -> void:
    _add_box("TreeTrunk", point + Vector3(0, 1.0, 0), Vector3(0.35, 2.0, 0.35), Color("#684a35"), false)
    var crown := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = 1.25
    mesh.height = 2.5
    crown.mesh = mesh
    crown.position = point + Vector3(0, 2.65, 0)
    crown.material_override = _mat(Color("#587451"))
    add_child(crown)

func _mat(color: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = color
    material.roughness = 0.9
    return material
